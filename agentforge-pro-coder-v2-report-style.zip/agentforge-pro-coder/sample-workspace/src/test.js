console.log("Tests passed");
